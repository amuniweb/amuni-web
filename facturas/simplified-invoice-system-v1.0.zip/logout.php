<?php
/*******************************************************************************
* Simplified PHP Invoice System                                                *
*                                                                              *
* Version: 1.0	                                                               *
* Author:  James Brandon                                    				   *
*******************************************************************************/

session_start();
session_destroy();

header("Location: index.php");

?>