1. Setup / Create your database
2. Extract the contents of invoice/* to your web directory
3. Open "includes/config.php"
4. Confirgure your database settings and all other settings within the config.php file
5. Import "setup.sql" via command line, phpMyAdmin or however you normally import SQL data.
6. Now navigate to your root installation on your browser and you will be presented with a login box.
7. Enter the default login details, username: admin - password: admin
8. That's it you all up and running!
